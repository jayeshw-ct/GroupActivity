int _cdecl Add(int u, int v);
double _cdecl Add(double u, double v);

int main() {
	int a = 1, b = 2, c = 0;
	c = Add(a, b);
	double i = 1.0, j = 2.0, k = 0.0;
	k = Add(i, j);
}

int _cdecl Add(int u, int v) {
	int result = 0;
	result = u + v;
	return result;
}

double _cdecl Add(double u, double v) {
	double result = 0.0;
	result = u + v;
	return result;
}

/*
- Note _cdecl is the default calling convetion in C/C++.
- There is no difference between _cdecl and __cdecl.
*/
