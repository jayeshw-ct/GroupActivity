/***** API Developer's Code *******/
#include <cstdio>

void PrintA(const char* s);
void PrintW(const wchar_t* ws);

void PrintA(const char* s) {
	printf("%s", s);
}

void PrintW(const wchar_t* ws) {
	printf("%S", ws);
}

/* Application Developer's Code *****/
int main() {
	PrintA("Hello, World\n");
	PrintW(L"Hello, World\n");
}

/*
- If the API is likely to have character/string type parameter then
  the developer must write API for both narrow and wide character/string parameter. 
*/