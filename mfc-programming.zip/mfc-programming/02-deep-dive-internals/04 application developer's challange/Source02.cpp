/***** API Developer's Code *******/
#include <cstdio>

void PrintA(const char* s);
void PrintW(const wchar_t* ws);

void PrintA(const char* s) {
	printf("%s", s);
}

void PrintW(const wchar_t* ws) {
	printf("%S", ws);
}

/* Application Developer's Code *****/
#define MBCS_

#ifdef UNICODE_
#define TEXT(x) L##x
#else
#define TEXT(x) x
#endif

#ifdef UNICODE_
#define Print PrintW
#else
#define Print PrintA
#endif

int main() {
	Print(TEXT("Hello, World\n"));
}
