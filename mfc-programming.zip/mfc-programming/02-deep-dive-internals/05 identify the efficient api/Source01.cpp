/***** API Developer's Code *******/
#include <cstdio>
#include <Windows.h>

void PrintA(const char* s);
void PrintW(const wchar_t* ws);

void PrintA(const char* s) {
	size_t size = strlen(s);
	wchar_t* pws = new wchar_t[size + 1];
	MultiByteToWideChar(CP_UTF8, 0, s, size + 1, pws, size + 1);
	PrintW(pws);
	delete pws;
	pws = nullptr;
}

void PrintW(const wchar_t* ws) {
	printf("%S", ws);
}

/* Application Developer's Code *****/
int main() {
	PrintA("Hello, World\n");
	PrintW(L"Hello, World\n");
}

/*
- Which call out of PrintA or PrintW is most efficient?
*/
